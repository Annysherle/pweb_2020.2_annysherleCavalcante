# Site Exemplo - By Xico

Essa pasta contém arquivos que podem te ajudar a completar o exercício.

O site que você deve imitar estão na pasta exercicio2, na raíz do seu repositório.

Outras instruções podem ser encontradas [no repositório da disciplina](https://github.com/pwebufersa/pweb_2020.2_xicoArrruda/).

Bom desempenho!

