package br.com.xico.cadpessoas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadpessoasXicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadpessoasXicoApplication.class, args);
	}

}
