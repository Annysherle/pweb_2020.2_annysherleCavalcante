# Site Exemplo - By Xico

Essa pasta contém apenas imagens.

Codifique o seu site a partir delas, usando HTML e CSS.

Outras instruções podem ser encontradas [no repositório da disciplina](https://github.com/pwebufersa/pweb_2020.2_xicoArrruda/).

Bom desempenho!