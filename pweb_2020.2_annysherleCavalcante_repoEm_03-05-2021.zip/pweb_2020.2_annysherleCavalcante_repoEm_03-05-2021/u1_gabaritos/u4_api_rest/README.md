# Exemplo de API Rest com Springboot, Swagger e PostgreSQL
By: Xico & Cesário Neto

Para acessar a interface do swagger usando o springfox 3.0.0 vá em:
http://localhost:8080/swagger-ui/index.html
