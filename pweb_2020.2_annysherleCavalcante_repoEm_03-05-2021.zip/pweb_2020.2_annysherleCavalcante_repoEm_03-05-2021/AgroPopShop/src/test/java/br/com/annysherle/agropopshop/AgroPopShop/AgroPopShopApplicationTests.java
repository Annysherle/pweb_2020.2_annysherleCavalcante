package br.com.annysherle.agropopshop.AgroPopShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgroPopShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
