package br.com.annysherle.AgroPopShop.AgroPopShop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgroPopShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgroPopShopApplication.class, args);
	}

}
