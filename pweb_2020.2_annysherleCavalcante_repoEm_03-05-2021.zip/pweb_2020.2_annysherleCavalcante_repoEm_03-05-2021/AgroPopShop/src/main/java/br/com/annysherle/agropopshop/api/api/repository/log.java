package br.com.annysherle.agropopshop.api.repository;

public class log {

}
