package com.google.common.base;

import springfox.documentation.RequestHandler;

public class Predicate implements java.util.function.Predicate<RequestHandler> {

	@Override
	public boolean test(RequestHandler t) {
		// TODO Auto-generated method stub
		return false;
	}

}
