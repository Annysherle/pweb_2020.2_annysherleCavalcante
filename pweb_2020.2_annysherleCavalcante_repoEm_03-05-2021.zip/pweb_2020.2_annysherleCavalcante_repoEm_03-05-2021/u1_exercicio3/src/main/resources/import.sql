﻿/*Primeira linha em branco - Spring não tava adicionado os valores*/
INSERT INTO pessoas (nome, email, data_nascimento, genero) VALUES ('Maria da Penha Maia Fernandes', 'mariaDaPenha@gov.br', parseDateTime('01/02/1945','dd/MM/yyyy'), 'Feminino');
INSERT INTO pessoas (nome, email, data_nascimento, genero) VALUES ('Pedro Álvares Cabral', 'pedrim@navio.br', parseDateTime('01/02/1467','dd/MM/yyyy'), 'Não Informado');
INSERT INTO pessoas (nome, email, data_nascimento, genero) VALUES ('Tarsila do Amaral', 'tarsila@abaporu.br', parseDateTime('01/09/1886','dd/MM/yyyy'), 'Não Informado');
INSERT INTO pessoas (nome, email, data_nascimento, genero) VALUES ('Oscar Niemeyer', 'obras@niemeyer.br', parseDateTime('15/12/1907','dd/MM/yyyy'), 'Não Informado');
INSERT INTO pessoas (nome, email, data_nascimento, genero) VALUES ('Joaquim Maria Machado de Assis', 'machado@assis.com', parseDateTime('21/06/1839','dd/MM/yyyy'), 'Masculino');
